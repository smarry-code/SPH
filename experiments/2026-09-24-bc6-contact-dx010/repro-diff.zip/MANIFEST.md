# Состав repro-diff.zip — BC6, четыре типа контакта при Δx = 0,1 мм

| Файл | Что это | Судьба |
|---|---|---|
| `MANIFEST.md` | этот файл | — |
| `HEAD.txt` | коммит, на котором сделаны прогоны | — |
| `01-plot-from-delta-x-label.patch` | `tests/test_e2e_bc6.cpp`: режим `--plot-from` учитывает `--delta-x` в подписи графика (разрешение и число частиц); без ключа поведение прежнее | **постоянное исправление**, предложено к коммиту; на момент записи не закоммичено |

**На расчёт патч не влияет.** Все четыре прогона выполнены бинарём,
собранным на коммите из `HEAD.txt` без изменений (его точная копия —
md5 `3fbcbba2a022a0423f8ba0a95722917f` на Windows; тип 3 — сборкой того же
коммита на Linux). Патч нужен только для шага сборки графика.

```bash
python -m zipfile -e repro-diff.zip repro/
git apply --check repro/01-plot-from-delta-x-label.patch
git apply repro/01-plot-from-delta-x-label.patch
cmake --build build --target test_e2e_bc6
```

Проверено 2026-09-24: патч накладывается (`git apply --check --reverse` на
дереве, где он уже наложен); подпись без `--delta-x` — «0,2 мм, 44 638
частиц», с `--delta-x=1e-4` — «0,1 мм, 177 645 частиц».
