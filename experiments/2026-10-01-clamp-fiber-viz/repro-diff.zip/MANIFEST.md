# repro-diff.zip: состав

Патчей нет: прогоны сняты на чистом дереве HEAD 8ae109beaa7d34380efe163597c1f65f170da91b
(`git status --short -- include src tests tools CMakeLists.txt` пуст; сцены Fiber, числа
`clamp_case::fib` и тест `e2e_clamp_EF1b_pc_smoke` уже закоммичены). Наложение не требуется.

| Файл | Содержание |
|---|---|
| `HEAD.txt` | полный хэш, автор, дата и заголовок коммита |
| `MANIFEST.md` | этот файл |

Снятие состояния: `git rev-parse HEAD` должен дать хэш из `HEAD.txt`, а
`git status --short -- include src tests tools CMakeLists.txt` не должен вывести ничего.
Незакоммиченными остаются только `Clamp/`, `build_clamp/`, `fiber/*.md`, `experiments/`;
на сборку и расчёт они не влияют.

Предыдущая версия этого каталога (HEAD 2b7f1a3 + три патча) заменена: те же сцены теперь в HEAD,
`reaction.csv` старой и новой версий совпали побайтово.
