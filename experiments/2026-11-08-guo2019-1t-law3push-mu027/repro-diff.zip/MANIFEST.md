# repro-diff.zip: состав

Патчей нет: бинарник `guo2019_shot` собран из архива чистого коммита
9437d7d627db2621f05fbcb15a7f46a1bc0ab26a (`git archive`, `~/mu027/src/SOURCE_COMMIT`), код расчёта совпадает
с `fiber_new` ec2439fabfd263cc64c3ca11c33bd9acdf2a5dfc (`git diff ec2439f 9437d7d` вне `experiments/` пуст).
Скрипты драйвера на сервере — закоммиченные версии:

| Серия | Коммит скриптов |
|---|---|
| 71 / 82 (`mu027_window`) | e51ed6c68a59f8a2e0254abf0bf8f6d4cac4a9fc |
| 69 / 70 (`mu027_v69_70`) | 3ae6e18d22b2672757c77dd9bd47c834e19eca69 |
| постобработка `fix_monitor_steps.py` | 42ea87aac21f6be490c621894a4654f556039312 |

Они отличаются от 9437d7d только в `experiments/2026-11-08-guo2019-1t-law3push-mu027/scripts/`; аргументы
`guo2019_shot` одинаковы. Наложение не требуется.

| Файл | Содержание |
|---|---|
| `HEAD.txt` | полный хэш, автор, дата и заголовок 9437d7d |
| `MANIFEST.md` | этот файл |

Проверка состояния: `git rev-parse 9437d7d` даёт хэш из `HEAD.txt`;
`git diff --stat ec2439f 9437d7d -- . ':(exclude)experiments'` ничего не выводит.
