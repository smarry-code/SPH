# Состав repro-diff.zip — BC6, искусственная вязкость

| Файл | Что это | Судьба |
|---|---|---|
| `MANIFEST.md` | этот файл | — |
| `HEAD.txt` | коммит, на который накладывается заплата | — |
| `01-bc6-alpha-env-override.patch` | временная заплата в `tests/test_e2e_bc6.cpp`: линейный коэффициент искусственной вязкости `alpha` берётся из переменной окружения `SPH_BC6_ALPHA`; при заданной переменной тест печатает строку `alpha (искусственная вязкость) переопределён` | **в репозиторий не коммитится**; накладывается перед серией, снимается после |

Без переменной окружения поведение теста не меняется.

```bash
python -m zipfile -e repro-diff.zip repro/
git apply --check repro/01-bc6-alpha-env-override.patch
git apply repro/01-bc6-alpha-env-override.patch
cmake --build build --target test_e2e_bc6
# ... серия ...
git apply -R repro/01-bc6-alpha-env-override.patch
cmake --build build --target test_e2e_bc6
```

Проверено 2026-09-23 на коммите из `HEAD.txt`: сборка с заплатой
компилируется; smoke (Δx = 0,8 мм, 1 мкс) с `SPH_BC6_ALPHA=0.25` печатает
строку о переопределении, конечное время 1,00956 мкс; без переменной строки
нет, 1,0106 мкс. Во время серии заплата наложена, поэтому архив проверен
`git apply --check --reverse`.
