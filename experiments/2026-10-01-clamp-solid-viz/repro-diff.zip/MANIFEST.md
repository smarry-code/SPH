# Состав repro-diff.zip (2026-10-01-clamp-solid-viz)

Патчей нет: прогоны сделаны на чистом дереве HEAD
`8ae109beaa7d34380efe163597c1f65f170da91b` (ветка `clamp`) — всё нужное для сборки и запуска
`test_e2e_clamp` (сцены Solid `tests/clamp_e2e_solid.hpp`, числа `tests/clamp_case.hpp`,
`tools/clamp_animate.py`) уже закоммичено. Проверено на момент прогонов:
`git diff --quiet HEAD -- CMakeLists.txt src include tests tools` — различий нет
(в рабочем дереве были только незакоммиченные документы `Clamp/`, `fiber/*.md`, каталоги
`experiments/` и `build_clamp/`; на сборку и расчёт они не влияют).

| Файл | Содержание |
|---|---|
| `HEAD.txt` | полный хэш, автор, дата, заголовок коммита |
| `MANIFEST.md` | этот файл |

Наложение: не требуется. Достаточно `git checkout 8ae109beaa7d34380efe163597c1f65f170da91b`
(или `git worktree add --detach <каталог> 8ae109beaa7d34380efe163597c1f65f170da91b`).
Сборка на g++ 15 требует флага `-DCMAKE_CXX_FLAGS="-include cmath"` — это обход давнего дефекта
`param.hpp`, он не является патчем исходников (подробности и команды — `REPRO.md`).
