# Состав repro-diff.zip — BC6, вклад XSPH

| Файл | Что это | Судьба |
|---|---|---|
| `MANIFEST.md` | этот файл | — |
| `HEAD.txt` | коммит, на который накладывается заплата | — |
| `01-bc6-epsilon-env-override.patch` | временная заплата в `tests/test_e2e_bc6.cpp`: коэффициент XSPH `epsilon` берётся из переменной окружения `SPH_BC6_EPSILON`; при наложенной переменной тест печатает строку `epsilon (XSPH) переопределён` | **в репозиторий не коммитится**; накладывается перед серией, снимается после неё |

Без переменной окружения поведение теста не меняется.

```bash
python -m zipfile -e repro-diff.zip repro/          # или unzip repro-diff.zip -d repro
git apply --check repro/01-bc6-epsilon-env-override.patch
git apply repro/01-bc6-epsilon-env-override.patch
cmake --build build --target test_e2e_bc6
# ... серия (scripts/run_all.sh) ...
git apply -R repro/01-bc6-epsilon-env-override.patch  # снять после серии
cmake --build build --target test_e2e_bc6
```

Проверено 2026-09-23 на коммите из `HEAD.txt`: `git apply --check` проходит,
сборка с заплатой компилируется и линкуется (одно предупреждение clang о
`getenv` из заголовков MSVC, на работу не влияет). Два smoke-прогона
(Δx = 0,8 мм, 1 мкс): с `SPH_BC6_EPSILON=0.05` строка о переопределении в логе
есть, конечное время 1,00716 мкс; без переменной строки нет, 1,0106 мкс.
