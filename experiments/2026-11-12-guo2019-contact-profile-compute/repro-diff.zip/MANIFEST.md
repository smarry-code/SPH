# repro-diff.zip — эксперимент 2026-11-12-guo2019-contact-profile-compute

База: `f1298aa` (см. `HEAD.txt`).

| # | Патч | Что | Влияние на траекторию |
|---|---|---|---|
| 01 | `01-prof-counts.patch` | `src/time_integration.cpp`: после стадии проекции на каждом шаге пишет в файл из `SPH_PROF_COUNTS` строку `step,time,ff_pairs,ff_prims,fs_prims,normal_ff,normal_fs,fric_ff_active,fric_fs_active`. Без переменной окружения ничего не делает. | нет — только чтение (проверено: `monitor.csv` P.cnt = P.t2, H.cnt = H.t2 побайтно) |

Временная диагностика: в ветку не коммитится, используется только сборкой `~/SPH_c3cnt` (прогоны P.cnt, H.cnt).

Наложение: `git apply 01-prof-counts.patch` (из корня дерева `f1298aa`).
Снятие: `git apply --reverse 01-prof-counts.patch`.
