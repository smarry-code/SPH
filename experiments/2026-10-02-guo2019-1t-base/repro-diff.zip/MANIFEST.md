# Отличия рабочего дерева на момент прогона

Архив описывает состояние, из которого получен прогон 1t scaled Guo 2019
(2026-10-01). Накладывать на чистое дерево коммита

```
e6e2d218ca2b837dfbbe6f5c64b05e99c6b286ab
Merge pull request #2 from smarry-code/weave
ветка fiber_new
```

Вся работа на момент прогона **не закоммичена** (лежит в рабочем дереве);
владелец коммитит только по своей команде. Патчи сняты настоящим `git diff`
(новые файлы через `git add -N`, затем сброс).

Патчи соответствуют рабочему дереву на момент прогонов 1 и 2 от 2026-10-01. Прогон 1 выполнен бинарником, собранным до появления опции `--save-t` в `guo2019_shot.cpp`; это не меняет расчёт — опция лишь задаёт `cfg.save_t`.

## Состав

| Файл | Файлы | Что это |
|---|---|---|
| `01-sph-same-body-only.patch` | `include/simulation_config.hpp`, `src/input.cpp`, `include/interactions/solid_sph.hpp`, `tests/test_sph_body_isolation.cpp` (новый) | опция «SPH-взаимодействие только внутри одного тела» + тест изоляции тел |
| `02-fiber-frames-reader.patch` | `tests/e2e_fiber_frames.hpp`, `tests/test_e2e_fiber_frames.cpp` (оба новые) | чтение кадров нитей для e2e + его тест |
| `03-guo2019-scene-monitor-smoke.patch` | `tests/guo2019_case.hpp`, `tests/guo2019_scene.hpp`, `tests/guo2019_monitor.hpp`, `tests/test_e2e_guo2019.cpp`, `tests/data/guo2019_initial_conditions.txt` (все новые) | сцена, монитор и дымовой тест Guo 2019, уровни включая `scaled` |
| `04-guo2019-shot-tool.patch` | `tools/guo2019/guo2019_shot.cpp` (новый) | инструмент прогона одного выстрела |
| `05-cmake-targets.patch` | `CMakeLists.txt` | цели сборки новых тестов и инструмента |
| `06-docs-guo2019-e2e.patch` | `fiber/guo2019-e2e.md` (новый) | документация e2e Guo 2019 |

Порядок наложения — по числовому префиксу. Патчи в LF; `git apply` на Windows
(autocrlf) и Linux проверен.

## Наложение

```bash
git checkout --detach e6e2d218ca2b837dfbbe6f5c64b05e99c6b286ab
for p in 01 02 03 04 05 06; do git apply --check $p-*.patch && git apply $p-*.patch; done
```

Проверить без изменений: `git apply --check <файл>`.

## Снятие

В обратном порядке:

```bash
for p in 06 05 04 03 02 01; do git apply -R $p-*.patch; done
```
